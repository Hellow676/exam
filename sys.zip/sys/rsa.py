# RSA with m^e mod n for encryption and c^d mod n for decryption
p = 61
q = 53
n = p * q  # n = 3233
phi = (p - 1) * (q - 1)  # phi = 3120
e = 17  # Public exponent

def mod_inverse(e, phi):
    t, new_t = 0, 1
    r, new_r = phi, e
    while new_r != 0:
        quotient = r // new_r
        t, new_t = new_t, t - quotient * new_t
        r, new_r = new_r, r - quotient * new_r
    if t < 0:
        t += phi
    return t

d = mod_inverse(e, phi)  # Private key

print("Public Key (e, n):", (e, n))
print("Private Key (d, n):", (d, n))

# RSA Encryption using c = m^e mod n
def encrypt(text):
    cipher = []
    for ch in text:
        m = ord(ch)  # convert char to ASCII (int)
        c = pow(m, e, n)  # c = m^e mod n
        cipher.append(c)
    return cipher

# RSA Decryption using m = c^d mod n
def decrypt(cipher):
    plain = ''
    for c in cipher:
        m = pow(c, d, n)  # m = c^d mod n
        plain += chr(m)
    return plain

message = "OK"
ciphertext = encrypt(message)
print("\nEncrypted:", ciphertext)

plaintext = decrypt(ciphertext)
print("Decrypted:", plaintext)
