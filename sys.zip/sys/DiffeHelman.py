q = 7  # A prime number 
alpha = 5  # A primitive root modulo q 
xa = 3  # Private key of user A 
xb = 4  # Private key of user B 
# Compute public key of user A: ya = alpha^xa mod q
ya = pow(alpha, xa) % q
print("ya:", ya) 
# Compute public key of user B: yb = alpha^xb mod q
yb = pow(alpha, xb) % q
print("yb:", yb)  
# Compute shared secret key at user A's side: ka = yb^xa mod q
ka = pow(yb, xa) % q
print("Shared key at source:", ka) 
# Compute shared secret key at user B's side: kb = ya^xb mod q
kb = pow(ya, xb) % q
print("Shared key at destination:", kb)  
