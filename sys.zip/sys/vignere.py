def generatekey(message, key):
    newkey = ""                        
    keylength = len(key)               
    for i in range(len(message)):      # For each letter in the message
        newkey += key[i % keylength]   # Repeat the key using modulo to loop around
    return newkey                      
def encrypt(message, key):
    key = generatekey(message, key)    
    ciphertext = ""                    
    for i in range(len(message)):      
        # Convert letters to numbers (A=0,take modulo 26, and convert back to character
        x = ((ord(message[i]) - ord('A')) + (ord(key[i]) - ord('A'))) % 26
        ciphertext += chr(x + ord('A'))  # Convert number back to character and add to ciphertext
    return ciphertext                  
def decrypt(ciphertext, key):
    key = generatekey(ciphertext, key)  
    originaltext = ""                   
    for i in range(len(ciphertext)):    # Loop through each character
        # Subtract key from cipher letter, add 26 to avoid negative, take modulo 26, convert back to character
        x = ((ord(ciphertext[i]) - ord('A')) - (ord(key[i]) - ord('A')) + 26) % 26
        originaltext += chr(x + ord('A'))  
    return originaltext               
message = "Iswar".upper()  
key = "KEY".upper()       
encrypted = encrypt(message, key)
print("Encrypted Message:", encrypted)
decrypted = decrypt(encrypted, key)
print("Decrypted Message:", decrypted)
