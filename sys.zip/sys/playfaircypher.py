def prepare_message(msg):
    msg = msg.upper().replace(" ", "")
    i = 0
    result = ""

    while i < len(msg):
        a = msg[i]
        b = ""

        if i + 1 < len(msg):
            b = msg[i + 1]

        if a == b:
            insert_char = 'Z' if a == 'X' else 'X'
            result += a + insert_char
            i += 1
        else:
            if b != "":
                result += a + b
                i += 2
            else:
                result += a + ('Z' if a != 'Z' else 'X')
                i += 1

    return result

def create_key_matrix(key):
    key = key.upper().replace(" ", "").replace("J", "I")  # J is merged with I
    seen = set()
    matrix = []

    for char in key:
        if char not in seen and char.isalpha():
            seen.add(char)
            matrix.append(char)

    for char in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if char not in seen:
            seen.add(char)
            matrix.append(char)

    key_matrix = [matrix[i*5:(i+1)*5] for i in range(5)]
    return key_matrix

def find_position(char, key_matrix):
    for i in range(5):
        for j in range(5):
            if key_matrix[i][j] == char:
                return i, j
    return None

def encrypt_pair(a, b, key_matrix):
    row1, col1 = find_position(a, key_matrix)
    row2, col2 = find_position(b, key_matrix)

    if row1 == row2:
        return key_matrix[row1][(col1 + 1) % 5] + key_matrix[row2][(col2 + 1) % 5]
    elif col1 == col2:
        return key_matrix[(row1 + 1) % 5][col1] + key_matrix[(row2 + 1) % 5][col2]
    else:
        return key_matrix[row1][col2] + key_matrix[row2][col1]

def decrypt_pair(a, b, key_matrix):
    row1, col1 = find_position(a, key_matrix)
    row2, col2 = find_position(b, key_matrix)

    if row1 == row2:
        return key_matrix[row1][(col1 - 1) % 5] + key_matrix[row2][(col2 - 1) % 5]
    elif col1 == col2:
        return key_matrix[(row1 - 1) % 5][col1] + key_matrix[(row2 - 1) % 5][col2]
    else:
        return key_matrix[row1][col2] + key_matrix[row2][col1]

def encrypt_message(msg, key_matrix):
    encrypted = ""
    for i in range(0, len(msg), 2):
        encrypted += encrypt_pair(msg[i], msg[i+1], key_matrix)
    return encrypted

def decrypt_message(cipher, key_matrix):
    decrypted = ""
    for i in range(0, len(cipher), 2):
        decrypted += decrypt_pair(cipher[i], cipher[i+1], key_matrix)
    return decrypted

# === RUNNING THE PLAYFAIR CIPHER ===
if __name__ == "__main__":
    message = input("Enter your msg: ")
    key = input("Enter key: ")

    processed = prepare_message(message)
    print("Prepared message:", processed)

    matrix = create_key_matrix(key)
    print("\nKey Matrix:")
    for row in matrix:
        print(row)

    cipher = encrypt_message(processed, matrix)
    print("\nEncrypted Message:", cipher)

    decrypted = decrypt_message(cipher, matrix)
    print("Decrypted Message:", decrypted)
# Playfair Cipher (Encryption & Decryption)

def generate_matrix(key):
    key = key.upper().replace("J", "I")  # Replace J with I for 5x5 matrix
    key += "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    seen, matrix = "", []
    for c in key:
        if c not in seen:
            seen += c
    for i in range(0, 25, 5):
        matrix.append(list(seen[i:i+5]))
    return matrix

def find_pos(matrix, ch):
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == ch:
                return i, j

def prepare_text(text):
    text = text.upper().replace("J", "I").replace(" ", "")
    i, prepared = 0, ""
    while i < len(text):
        a = text[i]
        b = text[i+1] if i+1 < len(text) else 'Z'
        if a == b:
            b = 'X' if a != 'X' else 'Z'
            prepared += a + b
            i += 1
        else:
            prepared += a + b
            i += 2
    if len(prepared) % 2:  # Ensure even length
        prepared += 'Z'
    return prepared

def encrypt(plain, key):
    matrix = generate_matrix(key)
    text = prepare_text(plain)
    cipher = ""
    for i in range(0, len(text), 2):
        r1, c1 = find_pos(matrix, text[i])
        r2, c2 = find_pos(matrix, text[i+1])
        if r1 == r2:
            cipher += matrix[r1][(c1+1)%5] + matrix[r2][(c2+1)%5]
        elif c1 == c2:
            cipher += matrix[(r1+1)%5][c1] + matrix[(r2+1)%5][c2]
        else:
            cipher += matrix[r1][c2] + matrix[r2][c1]
    return cipher

def decrypt(cipher, key):
    matrix = generate_matrix(key)
    text = cipher.upper().replace(" ", "")
    plain = ""
    for i in range(0, len(text), 2):
        r1, c1 = find_pos(matrix, text[i])
        r2, c2 = find_pos(matrix, text[i+1])
        if r1 == r2:
            plain += matrix[r1][(c1-1)%5] + matrix[r2][(c2-1)%5]
        elif c1 == c2:
            plain += matrix[(r1-1)%5][c1] + matrix[(r2-1)%5][c2]
        else:
            plain += matrix[r1][c2] + matrix[r2][c1]
    return plain

# --- Usage ---
key = input("Enter key: ")
mode = input("Encrypt or Decrypt (e/d)? ").lower()
text = input("Enter text: ")

if mode == 'e':
    print("Ciphertext:", encrypt(text, key))
else:
    print("Plaintext:", decrypt(text, key))
