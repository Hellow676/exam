 #include <string.h>
 #include <stdio.h>
 u void overflowed() { 
        printf("%s\n", "Execution Hijacked");
 }
 v void function1(char *str){
        char buffer[5];
        strcpy(buffer, str);
 }
 w void main(int argc, char *argv[])
 {
        function1(argv[1]);
        printf("%s\n", "Executed normally");
 }
 gcc -g -fno-stack-protector -z execstack -o overflowtest overflowtest.c 