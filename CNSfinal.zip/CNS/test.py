# Diffie-Hellman Key Exchange Example

# Public parameters (agreed by both parties)
p = 7 # Prime number
g = 5   # Primitive root modulo p

# Private keys (chosen secretly)
a = 3  # Source host's private key
b = 4 # Destination host's private key

# Public keys (computed and shared)
A = pow(g, a, p)  # Source computes A = g^a mod p
B = pow(g, b, p)  # Destination computes B = g^b mod p

# Each party computes the shared secret
shared_key_source = pow(B, a, p)  # (B^a mod p)
shared_key_destination = pow(A, b, p)  # (A^b mod p)

print("Source public key (A):", A)
print("Destination public key (B):", B)
print("Shared key at source:", shared_key_source)
print("Shared key at destination:", shared_key_destination)
