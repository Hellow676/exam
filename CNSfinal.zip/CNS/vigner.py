# Step 1: Get input
message = input("Enter the message (A-Z only): ").upper()
key = input("Enter the key (A-Z only): ").upper()

# Step 2: Extend the key
if len(key) != len(message):
    new_key = ""
    for i in range(len(message)):
        new_key += key[i % len(key)]
    key = new_key

# Step 3: Convert message and key to positions (A=0 to Z=25)
message_pos = []
key_pos = []

for char in message:
    message_pos.append(ord(char) - ord('A'))

for char in key:
    key_pos.append(ord(char) - ord('A'))

# Step 4: Encrypt (P + K) % 26
cipher_pos = []
for i in range(len(message)):
    val = (message_pos[i] + key_pos[i]) % 26
    cipher_pos.append(val)

cipher_text = ""
for val in cipher_pos:
    cipher_text += chr(val + ord('A'))

print("Encrypted Message:", cipher_text)

# Step 5: Decrypt (C - K + 26) % 26
decrypted_pos = []
for i in range(len(cipher_pos)):
    if cipher_pos[i] > key_pos[i]:
      val = (cipher_pos[i] - key_pos[i] ) % 26
    else:
        val = (cipher_pos[i] - key_pos[i] + 26) % 26
    decrypted_pos.append(val)

decrypted_text = ""
for val in decrypted_pos:
    decrypted_text += chr(val + ord('A'))

print("Decrypted Message:", decrypted_text)
