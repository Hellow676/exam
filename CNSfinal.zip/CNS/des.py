from Crypto.Cipher import DES

key_input = input("Enter 8-character key: ")
message_input = input("Enter 8-character message: ")


key = key_input.encode()
message = message_input.encode()


cipher = DES.new(key, DES.MODE_ECB)
ciphertext = cipher.encrypt(message)
print("Encrypted (hex):", ciphertext.hex())

decipher = DES.new(key, DES.MODE_ECB)
decrypted = decipher.decrypt(ciphertext)
print("Decrypted:", decrypted.decode())
