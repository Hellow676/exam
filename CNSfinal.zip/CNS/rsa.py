from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import binascii

def generate_keys():
    key = RSA.generate(2048)
    private_key = key
    public_key = key.publickey()
    return private_key, public_key

def encryption(public_key, plaintext):
    cipher = PKCS1_OAEP.new(public_key)
    ciphertext = cipher.encrypt(plaintext.encode())
    return binascii.hexlify(ciphertext).decode()

def decryption(private_key, ciphertext):
    ciphertext = binascii.unhexlify(ciphertext)
    cipher = PKCS1_OAEP.new(private_key)
    decrypted = cipher.decrypt(ciphertext)
    return decrypted.decode()

# === RUNNING THE RSA SYSTEM ===
if __name__ == "__main__":
    plaintext = input("Enter plaintext: ")
    print("Plaintext is:", plaintext)

    # Generate RSA keys
    private_key, public_key = generate_keys()

    # Encrypt
    cipher_text = encryption(public_key, plaintext)
    print("Ciphertext after encryption:", cipher_text)

    # Decrypt
    decrypted_text = decryption(private_key, cipher_text)
    print("Plaintext after decryption:", decrypted_text)
