q=7
alpha=5

xa=3
xb=4

ya=pow(alpha,xa)%q
yb=pow(alpha,xb)%q

print("ya:",ya)
print("yb:",yb)


ka=pow(yb,xa) % q
kb=pow(ya,xb)% q

print("Shared key at source:", ka)
print("Shared key at destination:", kb)