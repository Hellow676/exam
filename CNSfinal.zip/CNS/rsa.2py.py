import random
# Function to find gcd
def gcd(a, b):
    while b != 0:
        a,b=b,a%b
    return a
# Function to find modular inverse
def modinv(a,m):
    for x in range(1,m):
        if (a*x) % m == 1:
            return x
    return None
# Function to generate key pairs
def generate_keys():
    # Two prime numbers (for demo purposes, use small primes)
    p=61
    q=53
    n=p*q
    phi=(p-1)*(q-1)
    
    # choose e
    e=random.randrange(2,phi)
    while gcd(e,phi)!=1:
        e=random.randrange(2,phi)
    
    # Compute d
    d=modinv(e, phi)
    return ((e,n),(d,n))
# Function to encrypt message
def encrypt(public_key, plaintext):
    e,n =public_key
    return [pow(ord(char), e,n) for char in plaintext] #pow(plaintext,e,n) in case P.T is numeric

# Function to decrypt message
def decrypt(private_key, ciphertext):
    d,n =private_key
    return ''.join([chr(pow(char,d,n)) for char in ciphertext])  #pow(ciphertext, d,n)


#Main
public_key, private_key=generate_keys()
print(f"Public key: {public_key}\nPrivate key: {private_key}")

# message =numeric
message = "HELLO"
print(f"Original message: {message}")

encrypted_message = encrypt(public_key, message)
print(f"Encrypted message: {encrypted_message}")

decrypted_message=decrypt(private_key, encrypted_message)
print(f"Decrypted message: {decrypted_message}")