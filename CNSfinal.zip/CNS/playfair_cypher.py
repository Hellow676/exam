def prepare_message(msg):
    msg = msg.upper().replace(" ", "")
    i = 0
    result = ""

    while i < len(msg):
        a = msg[i]
        b = ""

        if i + 1 < len(msg):
            b = msg[i + 1]

        if a == b:
            insert_char = 'Z' if a == 'X' else 'X'
            result += a + insert_char
            i += 1
        else:
            if b != "":
                result += a + b
                i += 2
            else:
                result += a + ('Z' if a != 'Z' else 'X')
                i += 1

    return result

def create_key_matrix(key):
    key = key.upper().replace(" ", "").replace("J", "I")  # J is merged with I
    seen = set()
    matrix = []

    for char in key:
        if char not in seen and char.isalpha():
            seen.add(char)
            matrix.append(char)

    for char in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if char not in seen:
            seen.add(char)
            matrix.append(char)

    key_matrix = [matrix[i*5:(i+1)*5] for i in range(5)]
    return key_matrix

def find_position(char, key_matrix):
    for i in range(5):
        for j in range(5):
            if key_matrix[i][j] == char:
                return i, j
    return None

def encrypt_pair(a, b, key_matrix):
    row1, col1 = find_position(a, key_matrix)
    row2, col2 = find_position(b, key_matrix)

    if row1 == row2:
        return key_matrix[row1][(col1 + 1) % 5] + key_matrix[row2][(col2 + 1) % 5]
    elif col1 == col2:
        return key_matrix[(row1 + 1) % 5][col1] + key_matrix[(row2 + 1) % 5][col2]
    else:
        return key_matrix[row1][col2] + key_matrix[row2][col1]

def decrypt_pair(a, b, key_matrix):
    row1, col1 = find_position(a, key_matrix)
    row2, col2 = find_position(b, key_matrix)

    if row1 == row2:
        return key_matrix[row1][(col1 - 1) % 5] + key_matrix[row2][(col2 - 1) % 5]
    elif col1 == col2:
        return key_matrix[(row1 - 1) % 5][col1] + key_matrix[(row2 - 1) % 5][col2]
    else:
        return key_matrix[row1][col2] + key_matrix[row2][col1]

def encrypt_message(msg, key_matrix):
    encrypted = ""
    for i in range(0, len(msg), 2):
        encrypted += encrypt_pair(msg[i], msg[i+1], key_matrix)
    return encrypted

def decrypt_message(cipher, key_matrix):
    decrypted = ""
    for i in range(0, len(cipher), 2):
        decrypted += decrypt_pair(cipher[i], cipher[i+1], key_matrix)
    return decrypted

# === RUNNING THE PLAYFAIR CIPHER ===
if __name__ == "__main__":
    message = input("Enter your msg: ")
    key = input("Enter key: ")

    processed = prepare_message(message)
    print("Prepared message:", processed)

    matrix = create_key_matrix(key)
    print("\nKey Matrix:")
    for row in matrix:
        print(row)

    cipher = encrypt_message(processed, matrix)
    print("\nEncrypted Message:", cipher)

    decrypted = decrypt_message(cipher, matrix)
    print("Decrypted Message:", decrypted)
