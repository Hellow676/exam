def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    # Extended Euclidean Algorithm
    d_old, d = 0, 1
    r_old, r = phi, e
    while r != 0:
        q = r_old // r
        r_old, r = r, r_old - q * r
        d_old, d = d, d_old - q * d
    return d_old % phi

def rsa_keygen(p, q, e):
    n = p * q
    phi = (p - 1) * (q - 1)

    if gcd(e, phi) != 1:
        raise ValueError("e must be coprime with φ(n)")
    
    d = mod_inverse(e, phi)
    return (e, n), (d, n)

def encrypt(M, pub_key):
    e, n = pub_key
    return pow(M, e, n)

def decrypt(C, priv_key):
    d, n = priv_key
    return pow(C, d, n)

# Example usage
p = 61
q = 53
e = 17  # Commonly used public exponent

public_key, private_key = rsa_keygen(p, q, e)

message = 65  # Plaintext message must be less than n
cipher = encrypt(message, public_key)
decrypted = decrypt(cipher, private_key)

print("Public Key:", public_key)
print("Private Key:", private_key)
print("Original Message:", message)
print("Encrypted:", cipher)
print("Decrypted:", decrypted)
