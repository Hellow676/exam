
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# STEP 1: Generate RSA keys
print("Generating RSA keys")
key = RSA.generate(2048)
private_key = key
public_key = key.publickey()
print("Keys generated successfully.")

# STEP 2: Message to be sent
message = b"HII I am "

# STEP 3: Source signs the message
print("Source is signing the message...")
hash_obj = SHA256.new(message)
signature = pkcs1_15.new(private_key).sign(hash_obj)
print(" Message signed.")

# STEP 4: Destination verifies the signature
print(" Destination verifying the signature...")

try:
    pkcs1_15.new(public_key).verify(hash_obj, signature)
    print("Signature is valid. Source is authenticated.")
except (ValueError, TypeError):
    print("Signature verification failed!")
