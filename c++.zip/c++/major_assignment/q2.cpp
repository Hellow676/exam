#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int code;

public:
    void getPersonData() {
        cout << "Enter Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Code: ";
        cin >> code;
    }

    void displayPersonData() {
        cout << "Name: " << name << "\nCode: " << code << endl;
    }
};

class Account : virtual public Person {
protected:
    float pay;

public:
    void getAccountData() {
        cout << "Enter Pay: ";
        cin >> pay;
    }

    void displayAccountData() {
        cout << "Pay: " << pay << endl;
    }
};

class Admin : virtual public Person {
protected:
    int experience;

public:
    void getAdminData() {
        cout << "Enter Experience (years): ";
        cin >> experience;
    }

    void displayAdminData() {
        cout << "Experience: " << experience << " years" << endl;
    }
};

class Master : public Account, public Admin {
public:
    void getMasterData() {
        getPersonData();
        getAccountData();
        getAdminData();
    }

    void displayMasterData() {
        displayPersonData();
        displayAccountData();
        displayAdminData();
    }

    void updatePay(float newPay) {
        pay = newPay;
        cout << "Pay updated successfully!" << endl;
    }

    void updateExperience(int newExp) {
        experience = newExp;
        cout << "Experience updated successfully!" << endl;
    }
};

int main() {
    Master m;
    m.getMasterData();
    cout << "\n--- Master Object Details ---\n";
    m.displayMasterData();

    cout << "\nUpdating Pay and Experience...\n";
    m.updatePay(50000.50);
    m.updateExperience(10);

    cout << "\n--- Updated Master Object Details ---\n";
    m.displayMasterData();

    return 0;
}
