#include <iostream>
using namespace std;

const int MAX_ITEMS = 100;

class ShoppingList {
private:
    int itemCodes[MAX_ITEMS];
    float itemPrices[MAX_ITEMS];
    int itemCount;

public:
    ShoppingList() {
        itemCount = 0;
    }

    void addItem(int code, float price) {
        if (itemCount < MAX_ITEMS) {
            itemCodes[itemCount] = code;
            itemPrices[itemCount] = price;
            itemCount++;
            cout << "Item added successfully!" << endl;
        } else {
            cout << "Shopping list is full!" << endl;
        }
    }

    void deleteItem(int code) {
        bool found = false;
        for (int i = 0; i < itemCount; ++i) {
            if (itemCodes[i] == code) {
                found = true;
                for (int j = i; j < itemCount - 1; ++j) {
                    itemCodes[j] = itemCodes[j + 1];
                    itemPrices[j] = itemPrices[j + 1];
                }
                itemCount--;
                cout << "Item deleted successfully!" << endl;
                break;
            }
        }
        if (!found) {
            cout << "Item with code " << code << " not found." << endl;
        }
    }

    void printTotalValue() const {
        float total = 0;
        for (int i = 0; i < itemCount; ++i) {
            total += itemPrices[i];
        }
        cout << "Total value of order: Rs. " << total << endl;
    }

    void displayItems() const {
        if (itemCount == 0) {
            cout << "Shopping list is empty!" << endl;
            return;
        }
        cout << "Shopping List:\n";
        cout << "Code\tPrice\n";
        for (int i = 0; i < itemCount; ++i) {
            cout << itemCodes[i] << "\t" << itemPrices[i] << endl;
        }
    }
};

int main() {
    ShoppingList list;
    int choice, code;
    float price;

    do {
        cout << "\n--- Shopping List Menu ---\n";
        cout << "1. Add Item\n";
        cout << "2. Delete Item\n";
        cout << "3. Print Total Value\n";
        cout << "4. Display All Items\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter item code and price: ";
            cin >> code >> price;
            list.addItem(code, price);
            break;
        case 2:
            cout << "Enter item code to delete: ";
            cin >> code;
            list.deleteItem(code);
            break;
        case 3:
            list.printTotalValue();
            break;
        case 4:
            list.displayItems();
            break;
        case 5:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice! Try again." << endl;
        }
    } while (choice != 5);

    return 0;
}
