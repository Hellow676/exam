#include <iostream>
#include <cmath>
using namespace std;

class Account {
protected:
    string customerName;
    int accountNumber;
    string accountType;
    double balance;

public:
    Account(string name, int accNo, string type, double initialBalance)
        : customerName(name), accountNumber(accNo), accountType(type), balance(initialBalance) {}

    void deposit(double amount) {
        balance += amount;
        cout << "Amount deposited successfully. Updated balance: " << balance << endl;
    }

    void displayBalance() const {
        cout << "Customer: " << customerName << "\nAccount No: " << accountNumber
             << "\nAccount Type: " << accountType << "\nBalance: " << balance << endl;
    }

    virtual void withdraw(double amount) = 0; 
    virtual void computeInterest() = 0;
};

class SavingsAccount : public Account {
    double interestRate;

public:
    SavingsAccount(string name, int accNo, double initialBalance, double rate = 0.05)
        : Account(name, accNo, "Savings", initialBalance), interestRate(rate) {}

    void computeInterest() override {
        double interest = balance * pow(1 + interestRate, 1) - balance; 
        balance += interest;
        cout << "Interest added: " << interest << ", New balance: " << balance << endl;
    }

    void withdraw(double amount) override {
        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful. New balance: " << balance << endl;
        } else {
            cout << "Insufficient balance!" << endl;
        }
    }
};

class CurrentAccount : public Account {
    const double minBalance = 1000;
    const double penalty = 100;

public:
    CurrentAccount(string name, int accNo, double initialBalance)
        : Account(name, accNo, "Current", initialBalance) {}

    void computeInterest() override {
        cout << "No interest for current account." << endl;
    }

    void withdraw(double amount) override {
        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful. New balance: " << balance << endl;
            checkMinimumBalance();
        } else {
            cout << "Insufficient balance!" << endl;
        }
    }

    void checkMinimumBalance() {
        if (balance < minBalance) {
            balance -= penalty;
            cout << "Minimum balance not maintained! Penalty imposed. New balance: " << balance << endl;
        }
    }
};

int main() {
    cout << "Creating Savings Account...\n";
    SavingsAccount sav("Amit", 101, 5000);
    sav.displayBalance();
    sav.deposit(2000);
    sav.computeInterest();
    sav.withdraw(1000);
    sav.displayBalance();

    cout << "\nCreating Current Account...\n";
    CurrentAccount cur("Rohit", 202, 1200);
    cur.displayBalance();
    cur.deposit(300);
    cur.withdraw(1600); 
    cur.computeInterest();
    cur.displayBalance();

    return 0;
}
