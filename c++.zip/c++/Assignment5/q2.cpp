#include <iostream>
using namespace std;

class Shape {
protected:
    double x, y;

public:
    void getData() {
        cout << "Enter two dimensions: ";
        cin >> x >> y;
    }

    virtual void displayArea() {
        cout << "Area not defined for base Shape class." << endl;
    }
};

class Triangle : public Shape {
public:
    void displayArea() override {
        double area = 0.5 * x * y;
        cout << "Area of Triangle: " << area << endl;
    }
};

class Rectangle : public Shape {
public:
    void displayArea() override {
        double area = x * y;
        cout << "Area of Rectangle: " << area << endl;
    }
};

int main() {
    int choice;
    cout << "Choose shape:\n1. Triangle\n2. Rectangle\nEnter choice: ";
    cin >> choice;

    if (choice == 1) {
        Triangle tri;
        tri.getData();
        tri.displayArea();
    } else if (choice == 2) {
        Rectangle rect;
        rect.getData();
        rect.displayArea();
    } else {
        cout << "Invalid choice." << endl;
    }

    return 0;
}
