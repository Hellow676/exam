#include <iostream>
#include <string>
using namespace std;

class Staff {
protected:
    int code;
    string name;

public:
    void getdata() {
        cout << "Enter the code: ";
        cin >> code;
        cin.ignore(); 
        cout << "Enter your name: ";
        getline(cin, name);
    }

    void Display() {
        cout << "Code: " << code << "\nName: " << name << endl;
    }
};


class Teacher : public Staff {
    string subject;
    string publication;

public:
    void getdata() {
        Staff::getdata();
        cout << "Enter Subject: ";
        getline(cin, subject);
        cout << "Enter Publication: ";
        getline(cin, publication);
    }

    void displayTeacherDetails() {
        Staff::Display();
        cout << "Subject: " << subject << "\nPublication: " << publication << endl;
    }
};


class Officer : public Staff {
    string grade;

public:
    void getdata() {
        Staff::getdata();
        cout << "Enter Grade: ";
        getline(cin, grade);
    }

    void displayOfficerDetails() {
        Staff::Display();
        cout << "Grade: " << grade << endl;
    }
};

class Typist : public Staff {
protected:
    float speed;

public:
    void getdata() {
        Staff::getdata();
        cout << "Enter Typing Speed (wpm): ";
        cin >> speed;
    }

    void displayTypistDetails() {
        Staff::Display();
        cout << "Typing Speed: " << speed << " wpm" << endl;
    }
};

class Regular : public Typist {
public:
    void getdata() {
        Typist::getdata();
    }

    void displayRegularDetails() {
        Typist::displayTypistDetails();
    }
};

class Casual : public Typist {
    float daily_wages;

public:
    void getdata() {
        Typist::getdata();
        cout << "Enter Daily Wages: ";
        cin >> daily_wages;
    }

    void displayCasualDetails() {
        Typist::displayTypistDetails();
        cout << "Daily Wages: " << daily_wages << endl;
    }
};


int main() {
    int choice;
    cout << "Select Staff Type:\n";
    cout << "1. Teacher\n2. Officer\n3. Regular Typist\n4. Casual Typist\nChoice: ";
    cin >> choice;

    switch (choice) {
    case 1: {
        Teacher t;
        t.getdata();
        cout << "\n--- Teacher Details ---\n";
        t.displayTeacherDetails();
        break;
    }
    case 2: {
        Officer o;
        o.getdata();
        cout << "\n--- Officer Details ---\n";
        o.displayOfficerDetails();
        break;
    }
    case 3: {
        Regular r;
        r.getdata();
        cout << "\n--- Regular Typist Details ---\n";
        r.displayRegularDetails();
        break;
    }
    case 4: {
        Casual c;
        c.getdata();
        cout << "\n--- Casual Typist Details ---\n";
        c.displayCasualDetails();
        break;
    }
    default:
        cout << "Invalid choice." << endl;
    }

    return 0;
}
