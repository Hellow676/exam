#include <iostream>
#include <cstring>
using namespace std;

class BankAccount {
private:
    string name;
    int accNumber;
    string accType;
    float balance;

public:
    void assignInitialValues(string n, int accNo, string type, float bal) {
        name = n;
        accNumber = accNo;
        accType = type;
        balance = bal;
    }

    void deposit(float amount) {
        balance += amount;
    }

    void withdraw(float amount) {
        if (amount > balance)
            cout << "Insufficient balance!" << endl;
        else
            balance -= amount;
    }

    void display() const {
        cout << "Name: " << name << ", Balance: " << balance << endl;
    }
};

int main() {
    BankAccount acc;
    acc.assignInitialValues("John Doe", 1001, "Savings", 5000);
    acc.deposit(1500);
    acc.withdraw(2000);
    acc.display();
    return 0;
}
