#include <iostream>
using namespace std;

class BankAccount {
private:
    string name;
    int accNumber;
    string accType;
    float balance;

public:
    void assignInitialValues(string n, int accNo, string type, float bal) {
        name = n;
        accNumber = accNo;
        accType = type;
        balance = bal;
    }

    void deposit(float amount) {
        balance += amount;
    }

    void withdraw(float amount) {
        if (amount > balance)
            cout << "Insufficient balance!" << endl;
        else
            balance -= amount;
    }

    void display() const {
        cout << "Name: " << name << ", Balance: " << balance << endl;
    }
};

int main() {
    BankAccount customers[10];

    for (int i = 0; i < 10; ++i) {
        string name, type;
        int accNo;
        float bal;
        cout << "\nEnter details for customer " << i + 1 << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "Account Number: ";
        cin >> accNo;
        cout << "Account Type: ";
        cin >> type;
        cout << "Initial Balance: ";
        cin >> bal;

        customers[i].assignInitialValues(name, accNo, type, bal);
    }

    for (int i = 0; i < 10; ++i) {
        cout << "\nCustomer " << i + 1 << ": ";
        customers[i].display();
    }

    return 0;
}
