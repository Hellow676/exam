#include <iostream>
using namespace std;

class DB; // Forward declaration

class DM {
    int meters, centimeters;

public:
    DM(int m = 0, int cm = 0) : meters(m), centimeters(cm) {}

    void display() {
        cout << "Distance in meters & centimeters: " << meters << "m " << centimeters << "cm" << endl;
    }

    friend DM addDistance(DM, DB);
};

class DB {
    int feet, inches;

public:
    DB(int f = 0, int in = 0) : feet(f), inches(in) {}

    void display() {
        cout << "Distance in feet & inches: " << feet << "' " << inches << "\"" << endl;
    }

    friend DM addDistance(DM, DB);
};

DM addDistance(DM d1, DB d2) {
    float total_cm = d1.meters * 100 + d1.centimeters;
    float total_in = d2.feet * 12 + d2.inches;
    float total_cm_from_db = total_in * 2.54;
    float sum_cm = total_cm + total_cm_from_db;

    int result_m = sum_cm / 100;
    int result_cm = (int)sum_cm % 100;

    return DM(result_m, result_cm);
}

int main() {
    DM d1(2, 50);
    DB d2(3, 4);

    DM result = addDistance(d1, d2);
    result.display();
    return 0;
}
