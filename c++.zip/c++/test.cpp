#include <iostream>
using namespace std;

class Distance {
private:
    int feet;
    int inches;

public:
    // Constructor
    Distance(int f = 0, int i = 0) {
        feet = f;
        inches = i;
       
    }

   

    Distance operator+(const Distance& d) const {
    int totalFeet = feet + d.feet;
    int totalInches = inches + d.inches;

    totalFeet += totalInches / 12;
    totalInches = totalInches % 12;

    return Distance(totalFeet, totalInches);  // Directly return a temporary object
}
    // Display function
    void display() const {
        cout << feet << " feet " << inches << " inches" << endl;
    }
};

// Main function to demonstrate the functionality
int main() {
    Distance d1(5, 9);   // 5 feet 9 inches
    Distance d2(3, 11);  // 3 feet 11 inches

    Distance d3 = d1 + d2; // Uses overloaded +

    cout << "Distance 1: ";
    d1.display();
    cout << "Distance 2: ";
    d2.display();
    cout << "Sum of distances: ";
    d3.display();

    return 0;
}
