#include <iostream>
#include <cmath>
using namespace std;

class Number {
private:
    int value;

public:
    void setNumber(int n) {
        value = n;
    }

    int getNumber() {
        return value;
    }

    void printNumber() {
        cout << "Number: " << value << endl;
    }

    bool isNegative() {
        return value < 0;
    }

    bool isDivisibleBy(int n) {
        return n != 0 && value % n == 0;
    }

    int absoluteValue() {
        return abs(value);
    }
};


int main() {
    Number num;
    num.setNumber(-15);
    num.printNumber();



    if (num.isNegative()){
        cout << "Is negative? Yes" << endl;
    }else{
        cout << "Is negative? No" << endl;
    }
    if (num.isDivisibleBy(5)){
        cout << "Is divisible by 5? Yes" << endl;
     } else{
        cout << "Is divisible by 5? No" << endl;
     }
    cout << "Absolute value: " << num.absoluteValue() << endl;

    return 0;
}
