#include <iostream>
using namespace std;

class Vector {
private:
    float* arr;
    int size;

public:
    Vector(int n) {
        size = n;
        arr = new float[size];
        for (int i = 0; i < size; i++)
            arr[i] = 0.0;
    }

    void modify(int index, float value) {
        if (index >= 0 && index < size)
            arr[index] = value;
        else
            cout << "Invalid index!" << endl;
    }

    void multiply(float scalar) {
        for (int i = 0; i < size; i++)
            arr[i] *= scalar;
    }

    void display() const {
        cout << "(";
        for (int i = 0; i < size; i++) {
            cout << arr[i];
            if (i != size - 1)
                cout << ", ";
        }
        cout << ")" << endl;
    }

    Vector add(const Vector& v) {
        if (size != v.size) {
            cout << "Size mismatch! Cannot add vectors." << endl;
            return *this;
        }
        Vector result(size);
        for (int i = 0; i < size; i++)
            result.arr[i] = arr[i] + v.arr[i];
        return result;
    }

    ~Vector() {
        delete[] arr;
    }
};


int main() {
    Vector v1(3);
    v1.modify(0, 10);
    v1.modify(1, 20);
    v1.modify(2, 30);
    cout << "v1 = ";
    v1.display();

    v1.multiply(2.0);
    cout << "v1 after scalar multiplication by 2: ";
    v1.display();

    Vector v2(3);
    v2.modify(0, 1);
    v2.modify(1, 2);
    v2.modify(2, 3);
    cout << "v2 = ";
    v2.display();

    Vector v3 = v1.add(v2);
    cout << "v1 + v2 = ";
    v3.display();

    return 0;
}
