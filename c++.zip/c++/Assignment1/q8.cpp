#include <iostream>
#include <cmath>
using namespace std;

double power(double m, int n = 2) {
    return pow(m, n);
}

int main() {
    double m;
    int n;
    cout << "Enter number m: ";
    cin >> m;
    cout << "Enter power n (or 0 for default): ";
    cin >> n;

    if (n == 0)
        cout << "Result: " << power(m) << endl;
    else
        cout << "Result: " << power(m, n) << endl;

    return 0;
}
