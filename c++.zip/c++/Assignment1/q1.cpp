#include <iostream>
using namespace std;

enum Day { SUNDAY = 0, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY };

int main() {
    int dayNum;
    cout << "Enter a day number (0 to 6): ";
    cin >> dayNum;

    Day day = static_cast<Day>(dayNum);

    switch (day) {
        case SUNDAY: cout << "Sunday"; break;
        case MONDAY: cout << "Monday"; break;
        case TUESDAY: cout << "Tuesday"; break;
        case WEDNESDAY: cout << "Wednesday"; break;
        case THURSDAY: cout << "Thursday"; break;
        case FRIDAY: cout << "Friday"; break;
        case SATURDAY: cout << "Saturday"; break;
        default: cout << "Invalid day number";
    }

    return 0;
}
