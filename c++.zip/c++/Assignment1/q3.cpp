#include <iostream>
using namespace std;

// Function to create a float vector of size M using new
float* createVector(int M) {
    float* vec = new float[M];
    cout << "Enter " << M << " float values:\n";
    for (int i = 0; i < M; i++) {
        cout << "Element " << i + 1 << ": ";
        cin >> vec[i];
    }
    return vec;
}

int main() {
    int size;
    cout << "Enter size of vector: ";
    cin >> size;

    // Create vector
    float* myVector = createVector(size);

    // Display the vector
    cout << "Vector values: ";
    for (int i = 0; i < size; i++) {
        cout << myVector[i] << " ";
    }
    cout << endl;

    // Deallocate memory
    delete[] myVector;

    return 0;
}
