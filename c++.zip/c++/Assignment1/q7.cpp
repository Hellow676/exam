#include <iostream>
using namespace std;

#define MAX3(a,b,c) ((a > b && a > c) ? a : (b > c ? b : c))

int main() {
    int x, y, z;
    cout << "Enter 3 numbers: ";
    cin >> x >> y >> z;
    cout << "Largest is: " << MAX3(x, y, z) << endl;
    return 0;
}
