#include <iostream>
#include <cmath>
using namespace std;

double power(double m, int n = 2) {
    return pow(m, n);
}

int power(int m, int n = 2) {
    int result = 1;
    for (int i = 0; i < n; ++i)
        result *= m;
    return result;
}

int main() {
    double m1;
    int m2, n;

    cout << "Enter double m: ";
    cin >> m1;
    cout << "Enter int n: ";
    cin >> n;
    cout << "power(double, int) = " << power(m1, n) << endl;

    cout << "Enter int m: ";
    cin >> m2;
    cout << "power(int, int) = " << power(m2, n) << endl;

    return 0;
}
