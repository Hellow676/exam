#include <iostream>
using namespace std;


void readMatrix(int** matrix, int cols, int rows = 2) {
    for (int i = 0; i < rows; ++i)
        for (int j = 0; j < cols; ++j) {
            cout << "Enter element [" << i << "][" << j << "]: ";
            cin >> matrix[i][j];
        }
}

void displayMatrix(int** matrix, int cols, int rows = 2) {
    cout << "Matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j)
            cout << matrix[i][j] << " ";
        cout << endl;
    }
}

int main() {
    int rows = 2, cols;
    cout << "Enter number of columns (rows are set to 2 by default): ";
    cin >> cols;

    int** matrix = new int*[rows];
    for (int i = 0; i < rows; ++i)
        matrix[i] = new int[cols];

    readMatrix(matrix, cols);       
    displayMatrix(matrix, cols);    

    for (int i = 0; i < rows; ++i)
        delete[] matrix[i];
    delete[] matrix;

    return 0;
}
