#include <iostream>
#include <cstring>
using namespace std;

class Book {
private:
    char title[50];
    char author[50];
    char publisher[50];
    float price;

public:
    Book() {}

    Book(const char* t, const char* a, const char* p, float pr) {
        strcpy(title, t);
        strcpy(author, a);
        strcpy(publisher, p);
        price = pr;
    }

    void display() const {
        cout << "\nTitle: " << title << "\nAuthor: " << author
             << "\nPublisher: " << publisher << "\nPrice: " << price << endl;
    }

    bool search(const char* t, const char* a) const {
        return (strcmp(title, t) == 0 && strcmp(author, a) == 0);
    }
};

int main() {
    Book books[3] = {
        Book("C++ Primer", "Lippman", "Pearson", 599.50),
        Book("Let Us C", "Yashwant Kanetkar", "BPB", 299.00),
        Book("Programming in ANSI C", "Balagurusamy", "McGraw Hill", 399.75)
    };

    char searchTitle[50], searchAuthor[50];
    cout << "Enter title of book: ";
    cin.getline(searchTitle, 50);
    cout << "Enter author name: ";
    cin.getline(searchAuthor, 50);

    bool found = false;
    for (int i = 0; i < 3; ++i) {
        if (books[i].search(searchTitle, searchAuthor)) {
            cout << "\nBook found!";
            books[i].display();
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "\nSorry, book not available.";
    }

    return 0;
}
