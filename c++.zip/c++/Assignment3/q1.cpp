#include <iostream>
#include <cstring>
using namespace std;

class String {
private:
    char* str;

public:
    String() {
        str = new char[1];
        str[0] = '\0';
    }

    String(const char* s) {
        str = new char[strlen(s) + 1];
        strcpy(str, s);
    }

    String(const String& s) {
        str = new char[strlen(s.str) + 1];
        strcpy(str, s.str);
    }

    void assign(const String& s) {
        if (this != &s) {
            delete[] str;
            str = new char[strlen(s.str) + 1];
            strcpy(str, s.str);
        }
    }

    void concat(const String& s1, const String& s2) {
        delete[] str;
        str = new char[strlen(s1.str) + strlen(s2.str) + 1];
        strcpy(str, s1.str);
        strcat(str, s2.str);
    }

    void display() const {
        cout << str << endl;
    }

    ~String() {
        delete[] str;
    }
};

int main() {
    String s1;
    String s2("Well done!");
    String s3(" Bravo!");
    String s4;

    cout << "s1: "; s1.display();
    cout << "s2: "; s2.display();
    cout << "s3: "; s3.display();

    s4.concat(s2, s3);
    cout << "Concatenated s4: "; s4.display();

    s1.assign(s2);
    cout << "Copied s1 = s2: "; s1.display();

    return 0;
}
