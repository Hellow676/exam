#include <iostream>
#include <cstring>
using namespace std;

class String {
private:
    char* str;

public:
    String() {
        str = new char[1];
        str[0] = '\0';
    }

    String(const char* s) {
        str = new char[strlen(s) + 1];
        strcpy(str, s);
    }

    String(const String& s) {
        str = new char[strlen(s.str) + 1];
        strcpy(str, s.str);
    }

    String operator+(const String& s) {
        char* temp = new char[strlen(str) + strlen(s.str) + 1];
        strcpy(temp, str);
        strcat(temp, s.str);
        String result(temp);
        delete[] temp;
        return result;
    }

    String& operator=(const String& s) {
        if (this != &s) {
            delete[] str;
            str = new char[strlen(s.str) + 1];
            strcpy(str, s.str);
        }
        return *this;
    }

    void display() const {
        cout << str << endl;
    }

    ~String() {
        delete[] str;
    }
};

int main() {
    String s1;                    
    String s2("Well done!");     
    String s3(" Bravo!");
    String s4;

    cout << "s1: "; s1.display();
    cout << "s2: "; s2.display();
    cout << "s3: "; s3.display();

    s4 = s2 + s3;               
    cout << "Concatenated s4: "; s4.display();

    s1 = s2;
    cout << "Copied s1 = s2: "; s1.display();

    return 0;
}
