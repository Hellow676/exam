#include <iostream>
using namespace std;

class Complex {
private:
    float real, imag;

public:
    Complex(float r = 0, float i = 0) {
        real = r;
        imag = i;
    }

    void display() const {
        cout << real << " +j " << imag << endl;
    }

    static Complex addcomplex(const Complex& c1, const Complex& c2) {
        return Complex(c1.real + c2.real, c1.imag + c2.imag);
    }
};

int main() {
    Complex A(3.12, 5.65);
    Complex B(2.75, 1.21);
    Complex C;

    C = Complex::addcomplex(A, B);

    cout << "A = "; A.display();
    cout << "B = "; B.display();
    cout << "C = "; C.display();

    return 0;
}
