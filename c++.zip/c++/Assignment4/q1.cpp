#include <iostream>
#include <cmath>
#define M_PI 3.14
class Polar {
private:
    double r;
    double a;

public:
    Polar(double radius = 0, double angle = 0) : r(radius), a(angle) {}

    double getRadius() const { return r; }
    double getAngle() const { return a; }

    Polar operator+(const Polar& p) const {
        double x1 = r * cos(a);
        double y1 = r * sin(a);

        double x2 = p.r * cos(p.a);
        double y2 = p.r * sin(p.a);

        double x_sum = x1 + x2;
        double y_sum = y1 + y2;

        double r_sum = sqrt(x_sum * x_sum + y_sum * y_sum);
        double a_sum = atan2(y_sum, x_sum);

        return Polar(r_sum, a_sum);
    }

    void print() const {
        std::cout << "Radius: " << r << ", Angle: " << a << " radians" << std::endl;
    }
};

int main() {
    Polar p1(5, M_PI / 4);
    Polar p2(3, M_PI / 3);

    Polar p3 = p1 + p2;

    std::cout << "p1: ";
    p1.print();

    std::cout << "p2: ";
    p2.print();

    std::cout << "p1 + p2: ";
    p3.print();

    return 0;
}
