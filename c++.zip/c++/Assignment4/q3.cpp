#include <iostream>
using namespace std;

class FLOAT {
private:
    float value;

public:
    FLOAT(float v = 0.0) : value(v) {}

    FLOAT operator+(const FLOAT& other) const {
        return FLOAT(value + other.value);
    }

    FLOAT operator-(const FLOAT& other) const {
        return FLOAT(value - other.value);
    }

    FLOAT operator*(const FLOAT& other) const {
        return FLOAT(value * other.value);
    }

    FLOAT operator/(const FLOAT& other) const {
        if (other.value != 0)
            return FLOAT(value / other.value);
        else {
            cout << "Error: Division by zero" << endl;
            return FLOAT(0);
        }
    }

    void display() const {
        cout << value << endl;
    }
};

int main() {
    FLOAT f1(5.5), f2(2.0);

    FLOAT add = f1 + f2;
    FLOAT sub = f1 - f2;
    FLOAT mul = f1 * f2;
    FLOAT div = f1 / f2;

    cout << "Addition: "; add.display();
    cout << "Subtraction: "; sub.display();
    cout << "Multiplication: "; mul.display();
    cout << "Division: "; div.display();

    return 0;
}
